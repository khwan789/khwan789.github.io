﻿using UnityEngine;
using System.Collections;

public class ObstacleScript : MonoBehaviour {

	private float radius = 3.0f;

	public float Radius{
		get { return radius; }
	}
	
}

	