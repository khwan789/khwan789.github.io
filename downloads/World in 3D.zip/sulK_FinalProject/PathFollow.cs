﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PathFollow : Vehicle {

	public GameObject coin;
	public GameObject coinPrefab;
	protected List<GameObject> coins;

	public List<GameObject> COINS{
		get { return coins; }
	}

	//weighting
	public float seekWeight = 75.0f;
	
	//ultimate steering force that will be applied to acceleration
	private Vector3 ultimateForce;

	//define necessary weights for seeker
	public float safeDistance = 10.0f;
	public float avoidWeight = 50.0f;

	public Vector3[] ways;

	public int point;

	// Use this for initialization
	override public void Start () {
		base.Start ();

		ultimateForce = Vector3.zero;

		maxSpeed = 7;

		ways = new Vector3[8];

		point = 0;
	

		ways [0] = new Vector3 (0, 0.5f, 35);
		ways [1] = new Vector3 (25, 0.5f, 24);
		ways [2] = new Vector3 (22, 0.5f, 0);
		ways [3] = new Vector3 (28, 0.5f, -26);
		ways [4] = new Vector3 (0, 0.5f, -35);
		ways [5] = new Vector3 (-20, 0.5f, -20);
		ways [6] = new Vector3 (-35, 0.5f, 0);
		ways [7] = new Vector3 (-28, 0.5f, 25);

		for (int i = 0; i < ways.Length; i++) {
			coin = (GameObject)Instantiate (coinPrefab, ways [i], Quaternion.identity);
			//coins.Add (coin);
		}


	}
	
	// Update is called once per frame
	protected override void CalcSteeringForces(){
		ultimateForce = Vector3.zero;


		if (ways.Length > 0) {

			Vector3 onWay = ways[point];

			onWay = transform.position - onWay;


			if(onWay.magnitude <= 1){
					if(point == (ways.Length - 1)){
						point = 0;
					}
					else{
						point++;
					}
			}

		ultimateForce += Seek (ways[point]) * seekWeight;
		
		for(int i = 0; i < gm.Obstacles.Length; i++){
			ultimateForce += AvoidObstacle(gm.Obstacles[i],5) * avoidWeight;
		}

		ultimateForce = Vector3.ClampMagnitude (ultimateForce, maxForce);
		
		ApplyForce (ultimateForce);

		}

	}

	public void OnTriggerEnter(Collider other){
		if (other.tag == "Coin") {
			Destroy(other.gameObject);
		}
		
		coin = (GameObject)Instantiate (coinPrefab, ways [point], Quaternion.identity);
	}

}
