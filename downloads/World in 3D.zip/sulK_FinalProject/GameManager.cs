﻿using UnityEngine;
using System.Collections;
//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class GameManager : MonoBehaviour {

	public GameObject lion;
	public GameObject human;

	public GameObject lionPrefab;
	public GameObject humanPrefab;
	public GameObject obstaclePrefab;

	private GameObject[] obstacles;
	
	public GameObject[] Obstacles{
		get { return obstacles; }
	}

	public GameObject camera2;

	//center of flock, average flock direction, and list of flockers
	private Vector3 centroid;
	private Vector3 flockDirection;
	private List<GameObject> flock;
	
	public Vector3 Centroid{
		get { return centroid; }
	}
	public Vector3 FlockDirection{
		get { return flockDirection; }
	}
	public List<GameObject> Flock{
		get { return flock; }
	}

	bool humanAlive;
	bool cameraSet;

	void Start () {

		humanAlive = true;
		cameraSet = true;

		//make human
		Vector3 pos = new Vector3 (0, 0, 35);
		human = (GameObject)Instantiate(humanPrefab, pos, Quaternion.identity); // q.i no rotation

		//create lion flockers
		flock = new List<GameObject> ();

		for (int i = 0; i < 5; i++) {
			Vector3 posi = new Vector3 (Random.Range(-20,-10), 0, pos.z);
			lion = (GameObject)Instantiate(lionPrefab, posi, Quaternion.identity);
			flock.Add(lion);
		}

		//follow cam cube
		Camera.main.GetComponent<SmoothFollow> ().target = transform;
		//Camera.main.GetComponent<SmoothFollow> ().target = human.transform;

		//lions set human as target
		for (int i = 0; i < flock.Count; i++) {
			flock[i].GetComponent<Seeker>().seekerTarget = human;
		}

		//obstacle
		for (int i = 0; i < 15; i++) {
			Vector3 posi = new Vector3 (Random.Range(-35,35), 0, Random.Range(-35,35));
			Instantiate(obstaclePrefab, posi, Quaternion.identity);
		}
		//assigning obstacles into array
		obstacles = GameObject.FindGameObjectsWithTag ("Obstacle");

	}
	

	void Update () {

		CalcCentroid ();
		CalcFlockDirection ();

		transform.position = centroid;
		transform.forward = flockDirection;

		camera2.transform.position = new Vector3 (centroid.x, 30, centroid.z);

		float dist;

		for (int i = 0; i < flock.Count; i++) {

			dist = Vector3.Distance(human.transform.position, flock[i].transform.position);

			if(dist <= 1.5f){
				Destroy(human);
				humanAlive = false;
			}

			if(humanAlive == false){
				human = (GameObject)Instantiate(humanPrefab, new Vector3(0, 0, 35), Quaternion.identity);
				humanAlive = true;

				for (int j = 0; j < flock.Count; j++) {
					flock[j].GetComponent<Seeker>().seekerTarget = human;
				}
			}

			////change camera view////

			if(Input.GetKeyDown(KeyCode.Z)){
				cameraSet = true;
				if(cameraSet == true){
					Camera.main.GetComponent<SmoothFollow> ().target = transform;
				}
			}
			else if(Input.GetKeyDown(KeyCode.X)){
				cameraSet = false;
				Camera.main.GetComponent<SmoothFollow>().target = camera2.transform;

				//Camera.main.transform.position = new Vector3 (centroid.x, 30, centroid.z);
			}
		}
	
	}


	private void CalcCentroid(){
		//calculate center of the flock
		for (int i = 0; i < flock.Count; i++) {
			centroid += flock[i].transform.position;
			
		}
		centroid = centroid/flock.Count;
	}
	
	private void CalcFlockDirection(){
		for(int i = 0; i < flock.Count; i++){
			flockDirection += flock[i].transform.forward;
			
		}
		flockDirection = flockDirection/flock.Count;
		flockDirection = flockDirection.normalized;
	}
}

